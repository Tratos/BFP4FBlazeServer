function Log(text) {
	var t = document.createElement("LI");
	t.appendChild(document.createTextNode(text));
	$('#console-window').append(t);
}

function hackRefreshPage() {
	window.location.reload(true);
}

function hackExecute() {
	var command = $('#command').val();
	Log(eval(command));
}

function loadLevel(map, mode) {
	this.game.hostServer(map, mode);
}

function hackTest() {
	this.login.start();
	hackRefreshPage();
}

function hackJoin1() {
	this.matchmaking.joinByPlayerName("test-server", "");
}

function hackJoin2() {
	this.matchmaking.joinByBookmark("f5193367-c991-4429-aee4-8d5f3adab938", "");
}

function hackJoin3() {
	this.matchmaking.joinByMatchmaking();
}

function hackJoin4() {
    this.game.joinServer("Player A", "999");
}

function showLoading() {
	doll.visible = false;
	$("#previewdiv").css({
		"visibility": "hidden"
	});
	$("#loadingdiv").css({
		"visibility": "visible"
	});
}

function onTabClick(n) {
	for (var i = 1; i <= 3; i++)
		if (i == n) {
			$("#tab" + i).css("visibility", "visible");
			$("#tabbtn" + i).css("background-color", "#88f");
		}
	else {
		$("#tab" + i).css("visibility", "hidden");
		$("#tabbtn" + i).css("background-color", "#888");
	}
	if (n == 3)
	{
		$("#previewdiv").css("visibility", "visible");
		doll.visible = true;
	}
	else
	{
		$("#previewdiv").css("visibility", "hidden");
		doll.visible = false;
	}
}

function hackEquip() {
	var giveItemsErrorCodes = {
		0: "ErrNone",
		5003: "ErrAssetInvalid",
		5009: "ErrAssetLevel",
		5013: "ErrAssetMissingDependencies",
		5017: "ErrTooFewPrimaryWeapons",
		5018: "ErrTooManyPrimaryWeapons",
		5019: "ErrTooFewSecondaryWeapons",
		5020: "ErrTooManySecondaryWeapons",
		5021: "ErrInvalidAssetForTeam",
		5022: "ErrInvalidAssetForKit",
		5023: "ErrInvalidAttachmentParent",
		5024: "ErrTooFewMeleeWeapons",
		5025: "ErrTooManyMeleeWeapons"
	};

	var giveItemsBarCodes = {
		0: "Unknown bar",
		1: "Clothing Bar",
		2: "Equipment Bar",
		3: "Emote Bar",
		4: "Mission Bar",
		5: "Passive Inventory"
	};

	var items = {
		EquipmentBar: [], //weapons
		MissionBar: [], //wtf is that? D:
		VisualItems: [], //appereance
		PassiveItems: [], //boosters, abilities
	};

	var abilities = [],
		extras = [];

	var main = {},
		pistol = {
			id: 3006,
			count: null,
			position: 1,
		},
		knife = {
			id: 3027,
			count: null,
			position: 2,
		},
		tracerDart = {
			id: 2168,
			count: 1,
			position: 8,
		},
		grenade = {
			id: 2005,
			count: 5,
			position: 9,
		};

	//APC rocket
	abilities.push({
		id: 2006,
		count: 1,
	});

	//Tank machinegun
	abilities.push({
		id: 2018,
		count: 1,
	});

	//Heli
	abilities.push({
		id: 2007,
		count: 1,
	});

	//Jet
	abilities.push({
		id: 2008,
		count: 1,
	});

	switch (this.soldier.kit) {
		case 0: //Recon

			main = {
				id: 3024,
				count: null,
				position: 0,
			};

			extras.push({
				id: 2017,
				count: 1,
				position: 3,
			});

			break;
		case 1: //Assault

			main = {
				id: 3001,
				count: null,
				position: 0,
			};

			extras.push({
				id: 2023,
				count: 1,
				position: 3,
			});

			break;
		case 2: //Medic

			main = {
				id: 3003,
				count: null,
				position: 0,
			};

			extras.push({
				id: 2004,
				count: 1,
				position: 3,
			});

			break;
		case 3: //Engineer

			main = {
				id: 3018,
				count: null,
				position: 0,
			};

			extras.push({
				id: 2021,
				count: 1,
				position: 3,
			});

			extras.push({
				id: 2054,
				count: 1,
				position: 4,
			});

			break;
	}

	items.EquipmentBar.push(main);
	items.EquipmentBar.push(pistol);
	items.EquipmentBar.push(knife);

	$.map(extras, function (item) {
		items.EquipmentBar.push(item);
	});

	items.EquipmentBar.push(grenade);
	items.EquipmentBar.push(tracerDart);

	$.map(abilities, function (ability) {
		items.PassiveItems.push(ability);
	});

	var itemsJson = JSON.stringify(items);

	var results = this.soldier.giveItems(itemsJson);
	var resJson = JSON.parse(results);

	$.map(resJson, function (res) {
		var err = "ITEM ID: " + res.ItemId + " ERR: " + giveItemsErrorCodes[res.ErrCode] + " (" + res.ErrCode + ") BAR: " + res.CustBar + " Type: " + giveItemsBarCodes[res.CustBar];
		Log(err);
	});
	Log("Done.");
}

function showDebug()
{
	$("#FirebugIFrame").css("visibility","visible");
	$("#Firebug").css("visibility","visible");
}

function hideDebug()
{
	$("#FirebugIFrame").css("visibility","hidden");
	$("#Firebug").css("visibility","hidden");
}

function hackInit() {
	$("#tabbtn1").click(function () {
		onTabClick(1)
	});
	$("#tabbtn2").click(function () {
		onTabClick(2)
	});
	$("#tabbtn3").click(function () {
		onTabClick(3)
	});
	hideDebug();
	onTabClick(1);
	game.addEventHandler('onLoadingStart', 'showLoading');
	doll.init(300, 200);
	doll.setTeam(2);
	doll.setDestRect(100, 200, 300, 200);
	doll.camAzimuth = 205;
	doll.camZenith = 80;
	doll.camDistance = 2.3;
	doll.setCameraLookAt(0.05, 0.85, 0);
	doll.camTransitionTime = 0;
	setInterval(function () {
		doll.camAzimuth += 0.2;
	}, 10);
}
